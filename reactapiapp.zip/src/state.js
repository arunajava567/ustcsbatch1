//creation of state  with an array of users

const state = {
    users: [],
    isLoading: false
  };
  
  export default state;
  