import React,{Component} from 'react'
class About extends Component {
render() {
return (


 <div>
       This is About Page
 </div>

);

}

}

export default About;