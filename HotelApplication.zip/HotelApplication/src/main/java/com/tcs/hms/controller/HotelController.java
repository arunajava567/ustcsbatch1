package com.tcs.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.hms.entity.Hotel;
import com.tcs.hms.service.HotelService;

@RestController
public class HotelController {
	
	@Autowired
	HotelService hotelService;
	
	@GetMapping("/getallhotels")   //any browser
	public List<Hotel> listAllHotels() {
		
		return hotelService.listAllHotels();
		
	}
	
	@PostMapping("/addhotel")  //post ,put, delete   - postman
	public Hotel addHotel(@RequestBody Hotel hotel) {
		
		return hotelService.addHotel(hotel);
		
	}
	
	@PutMapping("/updatehotel")  //post ,put, delete   - postman
	public String updateHotel() {
		
		return "updating hotel";
		
	}
	@DeleteMapping("/deletehotel")  //post ,put, delete   - postman
	public String deleteHotel() {
		
		return "deleting hotel";
		
	}
	
	

}
