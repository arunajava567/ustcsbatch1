import { GET_EMPLOYEES } from '../actiontypes/actiontypes';
 import axios from 'axios';
 
 export const getEmployees = () => {
 return dispatch => {
 
   //return axios.get("http://localhost:8085/api/v1/employees").then((response) => {
       //data.json
       //npm install -D json-server concurrently
       //npx json-server data.json
     return axios.get("http://localhost:6700/employees").then((response) => {
 
 console.log(response);
 dispatch({ type: GET_EMPLOYEES, payload: response.data });
 
 })
 }
 }
