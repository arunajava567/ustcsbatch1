package com.tcs.SpringBootEmbededDBApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmbededDbAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
