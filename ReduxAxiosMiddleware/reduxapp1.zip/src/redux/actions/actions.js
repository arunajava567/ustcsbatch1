import { GET_EMPLOYEES } from '../actiontypes/actiontypes';
 import axios from 'axios';
 
 export const getEmployees = () => {
 return dispatch => {
 
    //return axios.get("http://localhost:8085/api/v1/employees").then((response) => {
      return axios.get("http://localhost:3000/employees").then((response) => {
 
 console.log(response);
 dispatch({ type: GET_EMPLOYEES, payload: response.data });
 
 })
 }
 }
