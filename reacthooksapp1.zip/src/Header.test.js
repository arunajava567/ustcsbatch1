import { render, screen } from '@testing-library/react';
import App from './App';

test('this is my Header test', () => {
  render(<Header/>);
  //const linkElement = screen.getByText(/learn react/i);
  expect("Capgemini - FSD React 2021 batch1).toBeInTheDocument();
});
