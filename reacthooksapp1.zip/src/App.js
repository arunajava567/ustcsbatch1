import React, {useState, useEffect,useRef} from 'react';
import DataLoader from './DataLoader'
export default function App() {
    //Define State
    const [name, setName] = useState({firstName: 'name', surname: 'surname'});
    const [title] = useState('BIO');
       //Call the use effect hook
       //componentDidMount() componentDidUpdate()
    useEffect(() => {
      setName({firstName: 'Sriram', surname: 'Vangala'})
    }, [])//pass in an empty array as a second argument
     return(
       <div>
        <div>
            <h1>Title: {title}</h1>
            <h3>Name: {name.firstName}</h3>
            <h3>Surname: {name.surname}</h3>
        </div>
        <div>
          <DataLoader/>

          <User/>
        </div>
        </div>
    );
};


function User() {
  const name = useRef("Aleem");  //initialization

  useEffect(() => {     // mounting 
   // setTimeout(() => {
      name.current = "Isiaka";
      console.log(name);
   // }, 50000);
  });
                        //render
  return (<div>
  <div>{name.current}</div>
    <div  ref={name}> Sriram</div> 
    </div>
    );
}
/*import React,{useState} from 'react'; 

function App() {  
  // Declare a new state variable, which we'll call "count"  
  const [count, setCount] = useState(0);   // react hook state initializtion, calling methods vased on event
  const [buttonText, setButtonText] = useState("Click me, please");

  return (  
    <div>  
      <h1> using  Hooks: useState</h1>
      <p>You clicked {count} times</p>  
      <button onClick={() => setCount(count + 1)}>  
        Click me  
      </button>  
      <button onClick={() => setButtonText("Thanks, been clicked!")}>
      {buttonText}
    </button>

      <h1> without hooks</h1>
      <AppwithSetState/>
    </div>  
  );  
}  
export default App;  

class AppwithSetState extends React.Component {  
  constructor(props) {  
    super(props);  
    this.state = {   count: 0   };  
  } 

  render() {  
    return (  
      <div>  
        <p><b>You clicked {this.state.count} times</b></p>  
        <button onClick={() => this.setState({ count: this.state.count + 1 })}>  
          Click me  
        </button>  
      </div>  
    );  
  }
}

import React,{useState} from 'react';    
import DataLoader from './DataLoader'
export default function App() {
 
  return (
    <div>
      <div>
      <DataLoader/>
    </div>
    </div>
  );
} 
*/


/*
class App extends React.Component {  
  constructor(props) {  
    super(props);  
    this.state = {   count: 0   };  
  }  
  render() {  
    return (  
      <div>  
        <p><b>You clicked {this.state.count} times</b></p>  
        <button onClick={() => this.setState({ count: this.state.count + 1 })}>  
          Click me  
        </button>  
      </div>  
    );  
  }
}
    export default App;
*/
/*


*/
/*import React, { useState } from 'react'
export default function App() {
  const [age, setAge] = useState(19);
  const handleClick = () => setAge(age + 1)
  return (
  // eslint-disable-next-line
      <div> 
          I am {age} Years Old 
        <div> 
        <button onClick={handleClick}>Increase my age! </button>
      </div>
   </div>
  );
}*/
/*import React, { Component } from 'react'

class App extends Component {
  render() {
    return (
  <React.Fragment>
    <h1> this is app component</h1>
  </React.Fragment>
    )
  }
}

export default App

*/

/*import React from 'react';

class App extends React.Component {
   constructor(props) {
      super(props);
      
      this.state = {
         data: 0
      }
      this.setNewNumber = this.setNewNumber.bind(this)
   };
   setNewNumber() {
      this.setState({data: this.state.data + 1})
   }
   render() {
      return (
         <div>
            <button onClick = {this.setNewNumber}>INCREMENT</button>
            <Content myNumber = {this.state.data}></Content>
         </div>
      );
   }
   
}
class Content extends React.Component {
   componentWillMount() {
      console.log('Component WILL MOUNT!')
   }
   componentDidMount() {
      console.log('Component DID MOUNT!')
   }
   componentWillReceiveProps(newProps) {    
      console.log('Component WILL RECIEVE PROPS!')
   }
   shouldComponentUpdate(newProps, newState) {
      return true;
   }
   componentWillUpdate(nextProps, nextState) {
      console.log('Component WILL UPDATE!');
   }
   componentDidUpdate(prevProps, prevState) {
      console.log('Component DID UPDATE!')
   }
   componentWillUnmount() {
      console.log('Component WILL UNMOUNT!')
   }
   render() {
      return (
         <>
            <h3>{this.props.myNumber}</h3>
         </>
      );
   }
   
}
export default App;

*/

/*const { ReactComponent } = require("*.svg");

class App extends Component {
render() {
  return(
      <React.Fragment>

        <h1> Fragment  tutorial </h1> <br></br>


      </React.Fragment>
  );
}


}  */

/*
import React,{Component} from 'react';  

  import styles from './mystyles.modules.css'
  import styled from 'styled-components';  
  import ReactTable from "react-table-6";
  import "./react-table.css";
class App extends Component {  
 
  render() {  

    const mystyle = {  
      color: "blue",  
      backgroundColor: "lightBlue",  
      padding: "10px",  
      fontFamily: "Arial"  
    };  

    return (  
      <div>  
      <h1 style={{color: "Green"}}>Welcome to RactCSSModule!</h1>  


      <p>Here, you can find all CS tutorials.</p>  

      <h1 style={mystyle}>React CSS with inline style</h1>  

      <Child/>
      <br></br>
      <StyledChild/>
      <br></br>
      <ChildReactTable/>
      </div>  
    );  
  }  
}  

	class Child extends React.Component {  
	  render() {  
	    return (  
	      <div>  
	      <h1 className={styles.mystyle}>Hello React CSS with my style  </h1>  
	      <p className={styles.parastyle}>It provides great CS tutorials. with para style </p>  
	      </div>  
	    );  
	  }  
	}  
  	
	  
	class StyledChild extends React.Component {  
  render() {  
	    const Div:any = styled.div`  
	            margin: 20px;  
	            border: 5px dashed green;  
	            &:hover {  
	            background-color: ${(props:any) => props.hoverColor};  
	            }  
	            `;  
	    const Title = styled.h1`  
	            font-family: Arial;  
	            font-size: 35px;  
	            text-align: center;  
	            color: palevioletred;  
	            `;  
	    const Paragraph = styled.p`  
	            font-size: 25px;  
	            text-align: center;  
	            background-Color: lightgreen;  
	            `;  
	    return (  
	       <div>            
	            <Title>Styled Components Example</Title>  
	            <p></p>  
	            <Div hoverColor="Orange">  
	                 <Paragraph> New styled paragraph</Paragraph>  
	            </Div>  
	        </div>  
	    );  
	  }  
	}  

  
  
  class ChildReactTable extends Component {
    
    render() {
      const data = [{
        name: 'Roy Agasthyan',
        age: 26
      },{
        name: 'Sam Thomason',
        age: 22
      },{
        name: 'Michael Jackson',
        age: 36
      },{
        name: 'Samuel Roy',
        age: 56
      },{
        name: 'Rima Soy',
        age: 28
      },{
        name: 'Suzi Eliamma',
        age: 28
      }]
  
      const columns = [{
        Header: 'customer Name',
        accessor: 'name'
      },{
        Header: 'customer Age',
        accessor: 'age'
      }]
  
      return (
            <div>
                <ReactTable
                  data={data}
                  columns={columns}
                  defaultPageSize = {3}
                  pageSizeOptions = {[3, 6]}
                />
            </div>      
      )
  
    }
  }
  

export default App;  
*/

/*import React, { Component } from 'react';
class App extends Component {
    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.input = React.createRef();  //uncontrolled component using DOM, ref
    }
    
    handleChange = (newText) => {
        console.log(newText);
    }
    render() {
        return (
            <div className="App2">
              
                <div className="container">
                    <input type="text"
                        placeholder="Your message here.."
                        ref={this.input}
                        onChange={(event) => this.handleChange(event.target.value)}
                    />
                </div>
            </div>
            
        );
    }
}
export default App;

*/
/*import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      show: false
    };
  }
  render() {
    return (
      <div className="App">
        <Todo />
      </div>
    );
  }
}

export default App;


class Todo extends Component {

  constructor(props) {
    super(props);

    this.state = {
      edit: false,
      id: null,
      mockData: [{
        id: '1',
        title: 'Buy Milk.',
        done: false,
        date: new Date()
      }, {
        id: '2',
        title: 'Meeting with Ali.',
        done: false,
        date: new Date()
      }, {
        id: '3',
        title: 'Tea break.',
        done: false,
        date: new Date()
      }, {
        id: '4',
        title: 'Go for a run.',
        done: false,
        date: new Date()
      }]
    }
  }

  onSubmitHandle(event) {
    event.preventDefault();

    this.setState({
      mockData: [...this.state.mockData, {
        id: Date.now(),
        title: event.target.item.value,
        done: false,
        date: new Date()
      }]
    });

    event.target.item.value = '';
  }

  onDeleteHandle() {
    let id = arguments[0];

    this.setState({
      // eslint-disable-next-line
      mockData: this.state.mockData.filter(item => {
        if (item.id !== id) {
          return item;
        }
      })
    });
  }

  onEditHandle(event) {
    this.setState({
      edit: true,
      id: arguments[0],
      title: arguments[1]
    });
  }

  onUpdateHandle(event) {
    event.preventDefault();

    this.setState({
      mockData: this.state.mockData.map(item => {
        if (item.id === this.state.id) {
          item['title'] = event.target.updatedItem.value;
          return item;
        }

        return item;
      })
    });

    this.setState({
      edit: false
    });
  }

  renderEditForm() {
    if (this.state.edit) {
      return <form onSubmit={this.onUpdateHandle.bind(this)}>
        <input type="text" name="updatedItem" className="item" defaultValue={this.state.title} />
        <button className="update-add-item">Update</button>
      </form>
    }
  }

  render() {
    return (
      <div>
        {this.renderEditForm()}
        <form onSubmit={this.onSubmitHandle.bind(this)}>
          <input type="text" name="item" className="item" />
          <button className="btn-add-item">Add</button>
        </form>
        <ul>
          {this.state.mockData.map(item => (
            <li key={item.id} className={ item.done ? 'done' : 'hidden' }>
              {item.title}
              <button onClick={this.onDeleteHandle.bind(this, item.id)}>Delete</button>
              <button onClick={this.onEditHandle.bind(this, item.id, item.title)}>Edit</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}
*/
//export default Todo;


/*
import React, {Component}  from 'react'
const numbers = [1, 2, 3, 4, 5];
function NumberList(props) {
  const numbers = props.numbers;
  const listItems = numbers.map((number) =>
    <li>{number}</li>
  );
  return (
    <ul>{listItems}</ul>
  );
}
class App extends Component{    
   render(){   
       return(   
           <div>   
                  <NumberList numbers={numbers} />
                  <ComplexList/>
           </div>         
           );   
   }   
}   
export default App;
const list = [
  {
    id: 'a',
    firstname: 'Robin',
    lastname: 'Wieruch',
    year: 1988,
  },
  {
    id: 'b',
    firstname: 'Dave',
    lastname: 'Davidds',
    year: 1990,
  },
];
 
const ComplexList = () => (
  <ul>
    {list.map(item => (
      <li key={item.id}>
        <div>{item.id}</div>
        <div>{item.firstname}</div>
        <div>{item.lastname}</div>
        <div>{item.year}</div>
      </li>
    ))}
  </ul>
);

*/
/*
import React,{Component} from 'react'
class App extends Component {
  constructor(props) {
    super(props);
  this.state = {
     ename :"Ram",
     salary:9898.99,
     desg:'SE'

     
  }
   this.handleEnameChange = this.handleEnameChange.bind(this);
   this.handleSalaryChange = this.handleSalaryChange.bind(this);
   this.handleDesgChange = this.handleDesgChange.bind(this);
   
   this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleEnameChange(event) {
    this.setState({ename: event.target.ename}); //this.setState()
  }
  handleSalaryChange(event) {
    this.setState({salary: event.target.salary}); //this.setState()
  }
  handleDesgChange(event) {
    this.setState({desg: event.target.desg}); //this.setState()
    console.log(this.state.desg);
  }
  handleSubmit(event) {
    alert('A name was submitted: ' + this.state.ename   +"  "+this.state.salary +"  "+this.state.desg);
    event.preventDefault();
  }
  render() {
   
    return (
    <div className="App">
        
       <form onSubmit={this.handleSubmit}>
        <label>
          Name:
          <input type="text" value={this.state.ename} onChange={this.handleEnameChange} />
          <input type="text" value={this.state.salary} onChange={this.handleSalaryChange} />
          <input type="text" value={this.state.desg} onChange={this.handleDesgChange} />
          
        </label>
        <input type="submit" value="Submit" />
      </form>
      <br></br>
      <h1> emp State : {this.state.ename}    {this.state.salary}    {this.state.desg}</h1>
        

    </div>


    );


  }
}
export default App;
*/

/*
function App() {
  //JSX
  return (
    <div className="App">
      <div>
        <Header/>
      </div>
      <h1> Welcome to React 16 Prorgamming </h1>

      <div> <Footer/></div>
    </div>
  );
}

export default App;



/*import   './App.css' 
//class , function 
import Header from './Header'
import Footer from './Footer'
import React, {Component} from 'react'
import FormDemo from './FormDemo'

class App extends Component {
  constructor(props) {
    super(props);
  this.state = {
    empname: "Ram",
    desg:"SE",
   value: ''
  }
   this.handleChange = this.handleChange.bind(this);
   this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChange(event) {
    this.setState({value: event.target.value}); //this.setState()
  }
  handleSubmit(event) {
    alert('A name was submitted: ' + this.state.value);
    event.preventDefault();
  }
  render() {
    var prod1={ id:"101",name:"Bag",price:"99"};
    return (
    <div className="App">
         <div>
               <Header/>
         </div>
         <h1> Welcome to React 16 Prorgamming- Class Component  </h1>
         <h1> emp State : {this.state.empname}    {this.state.desg} </h1>
        

      <div> <Footer  prod={prod1}/></div>
      <div>{ this.state.value} </div>
      <form onSubmit={this.handleSubmit}>
        <label>
          Name:
          <input type="text" value={this.state.value} onChange={this.handleChange} />
        </label>
        <input type="submit" value="Submit" />
      </form>
      <br></br>
      <div>  <FormDemo/></div>
    </div>


    );


  }
}
export default App;
*/

/*
function App() {
  //JSX
  return (
    <div className="App">
      <div>
        <Header/>
      </div>
      <h1> Welcome to React 16 Prorgamming </h1>

      <div> <Footer/></div>
    </div>
  );
}

export default App;
*/
