package com.tcs.hms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.hms.entity.Hotel;
import com.tcs.hms.repository.HotelRepository;
@Service
public class HotelService {

	@Autowired 
	HotelRepository hotelRepository;
	
public List<Hotel> listAllHotels() {
		
		return  hotelRepository.findAll();
		
	}

public Hotel addHotel(Hotel hotel) {
	
	return  hotelRepository.save(hotel);
	
}

}
