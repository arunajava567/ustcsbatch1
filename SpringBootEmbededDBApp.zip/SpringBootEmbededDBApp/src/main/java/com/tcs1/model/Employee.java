package com.tcs1.model;

//@GettersAndSetters
//@ToString
public class Employee {
	
	Integer id;
	String name;
	

}
