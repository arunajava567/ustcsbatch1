package com.tcs1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmbededDbAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmbededDbAppApplication.class, args);
	}

}

//to open h2 console after project is started 
// localhost:8090/h2-console/