//  1 using componnetDidMount ()
import {Component} from 'react'
export default class DataLoader extends Component {
  state = { data: [] };
  componentDidMount() {
    fetch("http://localhost:8085/api/v1/employees")
      .then(response => response.json())
      .then(data =>
        this.setState(() => {
          return { data };
        })
      );
  }

  render() {
    return (
      <div>
        <ul>
          {this.state.data.map(el => (
            <li key={el.firstName}>{el.lastName}   {el.emailId}</li>
          ))}
        </ul>
      </div>
    );
          }
        }


/* 2: useEffect hook

export default function DataLoader() {
    const [data, setData] = useState([]);
    useEffect(() => {
      fetch("http://localhost:8085/api/v1/employees")
        .then(response => response.json())
        .then(data => setData(data));
    });
    return (
      <div>
        <ul>
          {data.map(el => (
            <li key={el.id}>{el.firstName}  {el.lastName} {el.emailId}</li>
          ))}
        </ul>
      </div>
    );
  }
  */


// 3. custom hooks 
/*import React from "react";
import useFetch from "./useFetch";
export default function DataLoader(props) {
  const data = useFetch("http://localhost:8085/api/v1/employees");
  return (
    <div>
        <h1> using custom hooks</h1>
      <ul>        {data.map(el => (
           <li key={el.id}>{el.firstName}  {el.lastName} {el.emailId}</li>
        ))}
      </ul>
    </div>  );
    }

    */


